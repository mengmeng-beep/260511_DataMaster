package com.example.jpasecurity.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Getter @Setter
public class RegisterDto {

    private Map<String, Object> attributes; // OAuth2 원본 속성
    private String nameAttributeKey;        // 사용자 식별 키

    @NotBlank(message = "이름을 입력해주세요")
    private String name;

    @NotBlank(message = "아이디를 입력해주세요")
    private String username;

    @NotBlank(message = "비밀번호를 입력해주세요")
    @Size(min = 4, message = "비밀번호는 4자 이상이어야 합니다")
    private String password;

    // 소셜 로그인을 위한 e-mail 추가
    @NotBlank(message = "이메일을 입력해주세요")
    @Size(max=100, message = "이메일은 100자 이하로 입력해주세요.")
    @Email
    private String email;

    private String picture;
}
