package com.example.jpasecurity.service;

import com.example.jpasecurity.dto.RegisterDto;
import com.example.jpasecurity.entity.JpaMember;
import com.example.jpasecurity.repository.MemberRepository;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class MemberService implements OAuth2UserService<OAuth2UserRequest, OAuth2User> {
    private final MemberRepository memberRepository;
    private final PasswordEncoder passwordEncoder; // SecurityConfig에서 Bean 등록
    private final HttpSession httpSession;

    // 회원가입 — 비밀번호는 BCrypt로 암호화하여 저장
    @Transactional
    public JpaMember register(RegisterDto dto) {

        if (memberRepository.existsByUsername(dto.getUsername())) {
            throw new IllegalArgumentException("이미 사용 중인 아이디입니다.");
        }

        if (memberRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("이미 가입 된 이메일 입니다.");
        }

        JpaMember member = JpaMember.builder()
                .name(dto.getName())
                .username(dto.getUsername())
                .password(passwordEncoder.encode(dto.getPassword()))
                .email(dto.getEmail())
                .role("ROLE_USER")
                .build();

        return memberRepository.save(member);
    }

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest)
            throws OAuth2AuthenticationException {

        OAuth2UserService<OAuth2UserRequest, OAuth2User> delegate =
                new DefaultOAuth2UserService();

        OAuth2User oAuth2User = delegate.loadUser(userRequest);

        String registrationId =
                userRequest.getClientRegistration()
                        .getRegistrationId();

        String userNameAttributeName =
                userRequest.getClientRegistration()
                        .getProviderDetails()
                        .getUserInfoEndpoint()
                        .getUserNameAttributeName();

        RegisterDto dto = new RegisterDto();

        if ("google".equals(registrationId)) {

            dto.setName((String) oAuth2User.getAttributes().get("name"));
            dto.setEmail((String) oAuth2User.getAttributes().get("email"));
            dto.setPicture((String) oAuth2User.getAttributes().get("picture"));

        } else if ("naver".equals(registrationId)) {

            @SuppressWarnings("unchecked")
            Map<String, Object> response =
                    (Map<String, Object>) oAuth2User.getAttributes().get("response");

            dto.setName((String) response.get("name"));
            dto.setEmail((String) response.get("email"));
            dto.setPicture((String) response.get("profile_image"));
        }

        dto.setAttributes(oAuth2User.getAttributes());
        dto.setNameAttributeKey(userNameAttributeName);

        JpaMember user = saveOrUpdate(dto);

        httpSession.setAttribute("user", user);

        return new DefaultOAuth2User(
                Collections.singleton(
                        new SimpleGrantedAuthority(user.getRole())
                ),
                dto.getAttributes(),
                dto.getNameAttributeKey()
        );
    }

    private JpaMember saveOrUpdate(RegisterDto dto) {

        JpaMember user = memberRepository.findByEmail(dto.getEmail())
                .map(entity -> entity.update(
                        dto.getName(),
                        dto.getPicture()))
                .orElse(
                        JpaMember.builder()
                                .name(dto.getName())
                                .email(dto.getEmail())
                                .picture(dto.getPicture())
                                .username(dto.getEmail())
                                .password("SOCIAL_LOGIN")
                                .role("ROLE_USER")
                                .build()
                );

        return memberRepository.save(user);
    }
}